# How to install:

## Just download the file, unzip it, and drag the install.mel to Maya viewport and the tools will apear on the shelf!!